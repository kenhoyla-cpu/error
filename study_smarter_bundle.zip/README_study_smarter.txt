STUDY SMARTER — PROTOTYPE
==========================

FILES
- study_smarter_pro.html: the mobile-friendly web app. It runs in a browser.
- This is a prototype; it does not use a paid AI API or collect payments.

TEST ON ANDROID
1. Download study_smarter_pro.html to your phone.
2. Open it with a browser (if your phone's file manager offers "Open with").
3. Test the Study Coach, Practice & Flashcards, Study Planner, My Progress, and Product Page tabs.
4. Progress tasks are stored locally in that browser on that device.

PUBLISH AS A PUBLIC LINK WITH GITHUB PAGES (FREE)
1. Sign in to GitHub or create an account.
2. Create a NEW PUBLIC repository named: study-smarter
3. Upload study_smarter_pro.html and rename it to: index.html
4. Open the repository's Settings.
5. Open Pages (usually under Code and automation).
6. Under Build and deployment, choose "Deploy from a branch".
7. Select branch "main" and folder "/ (root)", then Save.
8. Wait for GitHub Pages to publish and copy the public URL shown in the Pages settings.

NOTES
- Do not upload private student data or passwords.
- This prototype has no payment checkout and no built-in AI API.
- The public page is a product demo, not yet a validated paid product.
- Before charging money, test it with students, fix issues, and check marketplace payout requirements for the Philippines.
